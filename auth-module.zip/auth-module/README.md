# Module Utilisateurs & Sécurité — Event Manager

Livrable du groupe « Utilisateurs et protection des accès » du projet Event Manager : un module backend
REST (Java 17, Spring Boot 3, Spring Security, JWT), prêt à être intégré par les autres groupes.
Ce module n'est pas destiné à être démontré seul dans un navigateur — c'est une brique que les autres
groupes appellent depuis leur propre code (mobile, autre service backend, etc.), voir « Guide
d'intégration » ci-dessous.

## État du livrable

- Code source complet : modèles, dépôts, services, contrôleurs, sécurité, tests (voir `src/`).
- 15 tests automatisés couvrant les cas nominaux et les attaques courantes (`mvn test`).
- Documentation des endpoints et du contrat d'intégration ci-dessous.
- Restent à faire par les groupes concernés : réinitialisation de mot de passe par email, limitation
  de débit par IP, déploiement en production (voir « Limites connues »).

## Compiler et exécuter les tests

```bash
mvn test                     # compile et exécute les 15 tests d'authentification et de sécurité
mvn spring-boot:run          # démarre le module en local, H2 en mémoire, port 8080 (pour développement/débogage uniquement)
```
En local, le module expose aussi une interface Swagger (http://localhost:8080/swagger-ui.html) utile
pour déboguer pendant le développement, mais elle ne fait pas partie du livrable fonctionnel : les autres
groupes consommeront l'API directement.

- Production : `SPRING_PROFILES_ACTIVE=prod` + variables `JWT_SECRET` (Base64, ≥ 32 octets),
  `DB_URL`, `DB_USER`, `DB_PASSWORD`. Générer un secret : `openssl rand -base64 48`

## Endpoints
| Méthode | URL | Auth | Description |
|---|---|---|---|
| POST | /api/auth/register | non | Inscription (rôle USER ou ORGANIZER) |
| POST | /api/auth/login | non | Retourne accessToken + refreshToken |
| POST | /api/auth/refresh | non | Nouveau couple de tokens (rotation) |
| POST | /api/auth/logout | non | Révoque le refresh token |
| GET/PUT | /api/users/me | Bearer | Consulter / modifier son profil |
| PUT | /api/users/me/password | Bearer | Changer son mot de passe |
| DELETE | /api/users/me | Bearer | Désactiver son compte |
| GET | /api/admin/users | ADMIN | Lister les utilisateurs |

## Guide d'intégration pour les autres groupes
1. Se connecter : `POST /api/auth/login` `{ "email": "...", "password": "..." }`
2. Envoyer le token à chaque requête : `Authorization: Bearer <accessToken>`
3. Quand l'access token expire (15 min, réponse 401), appeler `/api/auth/refresh` avec le refresh token.
4. Récupérer l'utilisateur courant dans un autre module Spring : `@AuthenticationPrincipal User user`.
5. Restreindre une route : `.requestMatchers("/api/events/manage/**").hasAnyRole("ORGANIZER","ADMIN")`.

Codes d'erreur : 400 données invalides · 401 non authentifié / identifiants invalides · 403 accès refusé ·
409 email déjà utilisé · 423 compte verrouillé (5 échecs → 15 min).

## Mesures de sécurité
BCrypt (coût 12) · JWT signé HS256 (15 min) · refresh tokens aléatoires stockés hachés (SHA-256), rotation et
détection de réutilisation · verrouillage après 5 échecs · messages d'erreur génériques + hash factice contre
l'énumération d'emails · validation des entrées · requêtes JPA paramétrées · pas de détails internes dans les erreurs ·
inscription ADMIN interdite.

## Limites connues / à faire
- Pas de réinitialisation du mot de passe par email (nécessite un service d'envoi).
- Pas de limitation de débit par IP (rate limiting) : à ajouter via un filtre ou un reverse proxy.
- Création du premier ADMIN : à faire directement en base ou via un script d'initialisation.
- Toujours servir derrière HTTPS en production.
